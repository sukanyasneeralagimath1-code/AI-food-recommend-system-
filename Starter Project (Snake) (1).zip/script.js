/* =========================================
   AI FOOD RECOMMENDATION SYSTEM
   JavaScript File
   ========================================= */


/* =========================================
   1. FOOD DATABASE
   ========================================= */

const foodData = {

    happy: [
        {
            name: "Cheese Pizza 🍕",
            image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=800&q=80",
            description: "You are feeling happy! Celebrate your mood with a delicious cheesy pizza."
        },
        {
            name: "Juicy Burger 🍔",
            image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80",
            description: "A delicious juicy burger is a fun choice for your happy mood!"
        }
    ],

    sad: [
        {
            name: "Chocolate Cake 🍫",
            image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80",
            description: "Enjoy a comforting chocolate dessert and give yourself a relaxing moment."
        },
        {
            name: "Hot Coffee ☕",
            image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=800&q=80",
            description: "Relax with a warm cup of coffee and take some time for yourself."
        }
    ],

    tired: [
        {
            name: "Creamy Pasta 🍝",
            image: "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=800&q=80",
            description: "You need some comfort food! Enjoy a warm and creamy pasta."
        },
        {
            name: "Hot Soup 🍲",
            image: "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=800&q=80",
            description: "A warm bowl of soup can be a comforting choice when you're tired."
        }
    ],

    romantic: [
        {
            name: "Italian Pasta ❤️",
            image: "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=800&q=80",
            description: "Make your romantic moment special with delicious Italian pasta."
        },
        {
            name: "Strawberry Dessert 🍓",
            image: "https://images.unsplash.com/photo-1464358859356-2a0d0b6d1a5b?auto=format&fit=crop&w=800&q=80",
            description: "Sweet moments deserve a sweet dessert!"
        }
    ],

    sick: [
        {
            name: "Vegetable Soup 🥣",
            image: "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=800&q=80",
            description: "A warm vegetable soup can be a comforting and light food choice."
        },
        {
            name: "Healthy Salad 🥗",
            image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80",
            description: "A fresh salad is a light and simple food option."
        }
    ],

    party: [
        {
            name: "Loaded Nachos 🎉",
            image: "https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?auto=format&fit=crop&w=800&q=80",
            description: "Party time! Loaded nachos are great for sharing with friends."
        },
        {
            name: "Cheese Burger 🍔",
            image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80",
            description: "Bring some delicious burger energy to your party!"
        }
    ],

    gym: [
        {
            name: "Healthy Salad 💪",
            image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80",
            description: "A fresh salad with vegetables can be a light meal option after exercise."
        },
        {
            name: "Protein Bowl 🥗",
            image: "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=800&q=80",
            description: "A balanced protein bowl can be a good way to refuel after exercise."
        }
    ]

};


/* =========================================
   2. GET HTML ELEMENTS
   ========================================= */

const mood = document.getElementById("mood");

const recommendBtn =
    document.getElementById("recommendBtn");

const loading =
    document.getElementById("loading");

const result =
    document.getElementById("result");

const foodImage =
    document.getElementById("foodImage");

const foodName =
    document.getElementById("foodName");

const foodDescription =
    document.getElementById("foodDescription");

const speakBtn =
    document.getElementById("speakBtn");

const favoriteBtn =
    document.getElementById("favoriteBtn");

const anotherBtn =
    document.getElementById("anotherBtn");

const history =
    document.getElementById("history");

const clearBtn =
    document.getElementById("clearBtn");


/* =========================================
   3. VARIABLES
   ========================================= */

let currentFood = null;

let historyData =
    JSON.parse(
        localStorage.getItem("foodHistory")
    ) || [];


/* =========================================
   4. RECOMMEND FOOD
   ========================================= */

function recommendFood() {

    const selectedMood =
        mood.value;


    /* Check mood */

    if (!selectedMood) {

        alert(
            "Please select your mood first 😊"
        );

        return;
    }


    /* Show loading */

    loading.classList.remove("hidden");

    result.classList.add("hidden");


    /* Small AI-style delay */

    setTimeout(() => {

        const foods =
            foodData[selectedMood];


        /* Choose random food */

        const randomIndex =
            Math.floor(
                Math.random() * foods.length
            );


        currentFood =
            foods[randomIndex];


        /* Display food */

        foodImage.src =
            currentFood.image;

        foodImage.alt =
            currentFood.name;

        foodName.textContent =
            currentFood.name;

        foodDescription.textContent =
            currentFood.description;


        /* Hide loading */

        loading.classList.add("hidden");

        result.classList.remove("hidden");


        /* Save history */

        addHistory(
            currentFood.name
        );


        /* Celebration */

        createConfetti();

    }, 1200);
}


/* =========================================
   5. RECOMMEND BUTTON
   ========================================= */

recommendBtn.addEventListener(
    "click",
    recommendFood
);


/* =========================================
   6. TRY ANOTHER FOOD
   ========================================= */

anotherBtn.addEventListener(
    "click",
    recommendFood
);


/* =========================================
   7. TEXT TO SPEECH
   ========================================= */

speakBtn.addEventListener(
    "click",
    () => {

        if (!currentFood) {

            return;
        }


        /* Stop previous speech */

        speechSynthesis.cancel();


        const text =
            `${currentFood.name}. ${currentFood.description}`;


        const speech =
            new SpeechSynthesisUtterance(text);


        speech.rate = 0.9;

        speech.pitch = 1.1;

        speech.volume = 1;


        speechSynthesis.speak(
            speech
        );

    }
);


/* =========================================
   8. FAVORITE
   ========================================= */

favoriteBtn.addEventListener(
    "click",
    () => {

        if (!currentFood) {

            return;
        }


        favoriteBtn.textContent =
            "💖 Added to Favorites";


        favoriteBtn.style.transform =
            "scale(1.08)";


        setTimeout(() => {

            favoriteBtn.textContent =
                "❤️ Favorite";

            favoriteBtn.style.transform =
                "scale(1)";

        }, 1500);

    }
);


/* =========================================
   9. ADD HISTORY
   ========================================= */

function addHistory(food) {

    historyData.unshift(food);


    /* Keep only 5 items */

    if (historyData.length > 5) {

        historyData.pop();

    }


    localStorage.setItem(
        "foodHistory",
        JSON.stringify(historyData)
    );


    displayHistory();
}


/* =========================================
   10. DISPLAY HISTORY
   ========================================= */

function displayHistory() {

    history.innerHTML = "";


    /* No history */

    if (historyData.length === 0) {

        const li =
            document.createElement("li");

        li.textContent =
            "No recommendations yet 🍽️";

        history.appendChild(li);

        return;
    }


    /* Display items */

    historyData.forEach(
        (food) => {

            const li =
                document.createElement("li");

            li.textContent =
                `🍴 ${food}`;

            history.appendChild(li);

        }
    );
}


/* =========================================
   11. CLEAR HISTORY
   ========================================= */

clearBtn.addEventListener(
    "click",
    () => {

        historyData = [];


        localStorage.removeItem(
            "foodHistory"
        );


        displayHistory();

    }
);


/* =========================================
   12. CONFETTI EFFECT
   ========================================= */

function createConfetti() {

    const emojis = [
        "🍕",
        "🍔",
        "🍝",
        "🥗",
        "🍜",
        "❤️",
        "✨",
        "🎉"
    ];


    for (
        let i = 0;
        i < 35;
        i++
    ) {

        const confetti =
            document.createElement("div");


        /* Random emoji */

        confetti.textContent =
            emojis[
                Math.floor(
                    Math.random() *
                    emojis.length
                )
            ];


        /* Position */

        confetti.style.position =
            "fixed";

        confetti.style.left =
            Math.random() * 100 + "vw";

        confetti.style.top =
            "-40px";


        /* Size */

        confetti.style.fontSize =
            Math.random() * 20 + 15 + "px";


        /* Layer */

        confetti.style.zIndex =
            "9999";


        confetti.style.pointerEvents =
            "none";


        document.body.appendChild(
            confetti
        );


        /* Animation */

        const animation =
            confetti.animate(

                [
                    {
                        transform:
                            "translateY(0) rotate(0deg)",

                        opacity: 1
                    },

                    {
                        transform:
                            `translateY(110vh) rotate(720deg)`,

                        opacity: 0
                    }
                ],

                {
                    duration:
                        Math.random() * 2000 + 1500,

                    easing:
                        "ease-out"
                }

            );


        /* Remove after animation */

        animation.onfinish =
            () => {

                confetti.remove();

            };

    }
}


/* =========================================
   13. IMAGE ERROR HANDLING
   ========================================= */

foodImage.addEventListener(
    "error",
    () => {

        foodImage.alt =
            "Food image unavailable";

    }
);


/* =========================================
   14. LOAD SAVED HISTORY
   ========================================= */

displayHistory();


/* =========================================
   END OF JAVASCRIPT
   ========================================= */